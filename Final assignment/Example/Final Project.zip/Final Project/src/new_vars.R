# Sneaky transformation to a data.table format
df_full_filtered <- as.data.table(df_full_filtered)
df_full_filtered[, unique_id := .I]

# Basically, for a patient, this rettrieves the number of people that entered
# In the emergency service during their stay
get_n_entries <- function(dataset, name_service, time_entry, time_exit) {
  dataset[
    name_service == service &
      entry >= time_entry & 
      entry <= time_exit,
    .N
  ]  
}

# This takes some time but this would have taken ages with dplyr
df_full_filtered[
  ,
  n_entries := get_n_entries(df_full_filtered, service, entry, exit_corrected),
  by = unique_id
]

df_full_filtered <- 
  as_tibble(df_full_filtered) %>% 
  group_by(service) %>% 
  mutate(
    los_hour = ceiling(los / 60),
    los_6h = if_else(los >= 360, ">= 6h", "< 6h"),
    n_entries_per_hour = n_entries / los_hour,
    period_length = difftime(max(entry), min(entry), units = "hours") %>%
      as.numeric(),
    total_patients = n(),
    total_avg_patients_per_hour = total_patients / period_length,
    relative_n_entries = n_entries_per_hour / total_avg_patients_per_hour,
  ) %>% 
  select(-los_hour, -total_avg_patients_per_hour, -unique_id)
